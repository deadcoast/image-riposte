"""SHROUD: image privacy and an explicitly experimental protection laboratory."""
__version__ = "0.1.0"
