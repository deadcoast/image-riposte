from __future__ import annotations
import io
import json
import re
import uuid
from pathlib import Path
from PIL import Image
from .errors import ShroudError
from .metrics import transport_report, fidelity, difference_image
from .sanitize import decode_clean, encode_clean, social_render, png_audit
from .policy import Policy
from .store import workspace_lock, find_image, safe_child, atomic_clean_write, check_root

METHODS = {"external", "glaze", "nightshade", "photoguard", "mist", "diffusionguard", "dct-shield", "i2vguard"}

def _master(root: Path, identifier: str):
    from .organizer import audit_workspace
    if audit_workspace(root)["checkpoint"] != "COMPLETE":
        raise ShroudError("ORGANIZATION_CHECKPOINT_REQUIRED")
    row = find_image(root, identifier)
    with Image.open(safe_child(root, row["relative"])) as im:
        pixels = im.copy()
    return row, pixels

def _store_trial(root: Path, row: dict, clean: Image.Image, candidate: Image.Image, report: dict) -> dict:
    trial = uuid.uuid4().hex
    prefix = f".shroud/lab/{trial}"
    hashes = {}
    for name, image in (("clean",clean),("candidate",candidate),("difference",difference_image(clean,candidate))):
        data = encode_clean(image,row["day"])
        hashes[name] = png_audit(data)["sha256"]
        atomic_clean_write(root,f"{prefix}/{name}.png",data)
    report = {"id":trial, "image_id":row["id"], "date":row["day"], "width":clean.width,"height":clean.height,
              "source_clean_sha256":row["sha256"], "artifact_sha256": hashes, **report, "fidelity":fidelity(clean,candidate),
              "transport":transport_report(clean,candidate)}
    path = safe_child(root, f"{prefix}/report.json")
    path.write_text(json.dumps(report,indent=2,allow_nan=False))
    return report

def compare_external(root: Path, identifier: str, candidate_path: Path, max_edge: int = 1536, method: str = "external") -> dict:
    if method not in METHODS:
        raise ShroudError("METHOD_INVALID")
    with workspace_lock(root):
        row, master = _master(root, identifier)
        clean = social_render(master,max_edge)
        # External path remains external. Raw bytes/filename are never imported.
        candidate = decode_clean(candidate_path,Policy()).pixels
        if candidate.size != clean.size:
            raise ShroudError("CANDIDATE_SIZE_MISMATCH")
        candidate = social_render(candidate,max_edge)
        return _store_trial(root,row,clean,candidate,{"method":method,"evidence_level":"PIXEL_TRANSPORT_ONLY",
            "ai_protection":"UNVERIFIED", "external_source":"Not copied into workspace; original outside workspace is unchanged."})

def create_candidate(root: Path, identifier: str, vae_dirs: list[Path], max_edge: int = 1536,
                     epsilon: int = 4, steps: int = 48, seed: int = 7, progress=None) -> dict:
    from .optimizer import LocalVAE, GuardConfig, protect
    if not vae_dirs:
        raise ShroudError("NO_MODEL_NO_PROTECTION")
    with workspace_lock(root):
        row, master = _master(root,identifier)
        clean = social_render(master,max_edge)
        encoders = [LocalVAE(path) for path in vae_dirs]
        candidate, report = protect(clean, encoders, GuardConfig(epsilon_255=epsilon,steps=steps,seed=seed),progress)
        return _store_trial(root,row,clean,candidate,report)

def trial_report(root: Path, identifier: str) -> dict:
    if not re.fullmatch(r"[0-9a-f]{32}",identifier):
        raise ShroudError("TRIAL_NOT_FOUND")
    path = safe_child(root,f".shroud/lab/{identifier}/report.json")
    try:
        return json.loads(path.read_text())
    except (ValueError,OSError):
        raise ShroudError("TRIAL_NOT_FOUND") from None

def trials(root: Path) -> list[dict]:
    check_root(root)
    folder = safe_child(root,".shroud/lab")
    if not folder.exists():
        return []
    result=[]
    for path in sorted(folder.iterdir(),reverse=True):
        if re.fullmatch(r"[0-9a-f]{32}",path.name):
            try:
                result.append(trial_report(root,path.name))
            except ShroudError:
                pass
    return result

def export_candidate(root: Path, identifier: str, acknowledge_unverified: bool = False) -> dict:
    if not acknowledge_unverified:
        raise ShroudError("ACKNOWLEDGE_UNVERIFIED_REQUIRED")
    with workspace_lock(root):
        report = trial_report(root,identifier)
        data = safe_child(root,f".shroud/lab/{identifier}/candidate.png").read_bytes()
        result = png_audit(data)
        if result["sha256"] != report["artifact_sha256"]["candidate"]:
            raise ShroudError("CANDIDATE_CHANGED")
        if result["date"] != report["date"]:
            raise ShroudError("TRIAL_DATE_MISMATCH")
        relative = f".shroud/exports/{identifier}/candidate.png"
        dest = safe_child(root,relative)
        if not dest.exists():
            atomic_clean_write(root,relative,data)
        elif png_audit(dest.read_bytes())["sha256"] != result["sha256"]:
            raise ShroudError("EXPORT_CHANGED")
        return {"relative":relative,"metadata":"DATE_ONLY","ai_protection":"UNVERIFIED"}
