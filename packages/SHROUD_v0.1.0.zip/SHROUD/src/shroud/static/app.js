'use strict';
const $ = id => document.getElementById(id);
const state = {images:[], trials:[], selected:null, trial:null, view:'library', size:'ALL', folder:'', search:'', mode:'split', plan:false};
const blobs = new Map();
const fragment = new URLSearchParams(location.hash.slice(1));
if(fragment.has('token')) { sessionStorage.setItem('shroud-session', fragment.get('token')); history.replaceState(null,'',location.pathname); }
const token = sessionStorage.getItem('shroud-session') || '';
let busyJob = null, lastJobs = new Set(), pollTimer, labRevision = 0;
async function api(path, body) {
  const response = await fetch('/api/'+path,{method:body === undefined?'GET':'POST',headers:{'X-Shroud-Token':token,...(body === undefined?{}:{'Content-Type':'application/json'})},body:body === undefined?undefined:JSON.stringify(body),cache:'no-store'});
  const value = await response.json();
  if(!response.ok) throw new Error(value.code || 'REQUEST_FAILED');
  return value;
}
function toast(message){ $('toast').textContent=message; $('toast').hidden=false; clearTimeout(toast.timer); toast.timer=setTimeout(()=>$('toast').hidden=true,6000); }
function error(e){ toast(String(e.message||'OPERATION_FAILED').replaceAll('_',' ')); }
async function imageURL(path){
  if(blobs.has(path)) return blobs.get(path);
  const response=await fetch('/api/'+path,{headers:{'X-Shroud-Token':token},cache:'no-store'});
  if(!response.ok) throw new Error('IMAGE_READ_FAILED');
  const url=URL.createObjectURL(await response.blob()); blobs.set(path,url); return url;
}
async function loadImage(element,path){ element.dataset.imagePath=path; try{ const url=await imageURL(path); if(element.dataset.imagePath===path)element.src=url; }catch(e){ if(element.dataset.imagePath===path)element.removeAttribute('src'); } }
function el(tag, cls, text){const item=document.createElement(tag);if(cls)item.className=cls;if(text!==undefined)item.textContent=text;return item;}
function shortName(row){return row.relative.split('/').pop();}
function bin(row){return row.relative.split('/')[2];}
function select(id){ state.selected=state.images.find(i=>i.id===id)||null; state.trial=state.trials.find(t=>t.image_id===id)||null; renderGallery(); renderInspector(); renderLab(); }
function setView(view){
  state.view=view;
  ['library','lab','evidence'].forEach(v=>$(v+'-view').hidden=v!==view);
  document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  const data={library:['01 / COLLECTION','Artwork library','Keep the art.','Lose the exposure.','Clean source images. Deliberate protection. Evidence before confidence.'],lab:['02 / EXPERIMENT','Protection lab','Preserve the image.','Challenge the model.','Compare what viewers see. Test what survives. Keep unverified claims out of the export.'],evidence:['03 / RESEARCH','Evidence register','Make claims smaller.','Make the evidence stronger.','A live-in-the-app register of methods, threat models, and implementation boundaries.']}[view];
  $('section-number').textContent=data[0];$('view-crumb').textContent=data[1].toUpperCase();$('page-title').replaceChildren(document.createTextNode(data[2]+' '),el('em','',data[3]));$('page-subtitle').textContent=data[4];
  if(view==='lab')renderLab();
  if(view==='evidence')renderMethods();
}
function renderTree(){
  const tree=$('tree');tree.replaceChildren();const groups={};
  for(const item of state.images){const [year,month]=item.relative.split('/');groups[year]??={};groups[year][month]=(groups[year][month]||0)+1;}
  for(const year of ['2026','2025','2024','EVERYTHING_ELSE']){
    if(!groups[year])continue;
    const detail=el('details','year');detail.open=true;detail.append(el('summary','',year));
    for(const month of ['January','February','March','April','May','June','July','August','September','October','November','December']){
      if(!groups[year][month])continue;
      const key=year+'/'+month;const button=el('button','folder'+(state.folder===key?' selected':''));button.append(document.createTextNode(month),el('span','',String(groups[year][month])));
      button.onclick=()=>{state.folder=key;renderTree();renderGallery();setView('library');};detail.append(button);
    }tree.append(detail);
  }
  if(!state.images.length)tree.append(el('p','quiet','Folders appear after your first import.'));
}
function renderGallery(){
  const gallery=$('gallery');gallery.replaceChildren();
  const filtered=state.images.filter(i=>(state.size==='ALL'||bin(i)===state.size)&&(!state.folder||i.relative.startsWith(state.folder+'/'))&&(!state.search||(i.relative+' '+i.day).toLowerCase().includes(state.search)));
  $('empty').hidden=state.images.length>0;
  $('visible-count').textContent=filtered.length+' ITEMS';$('collection-label').textContent=(state.folder||'ALL ARTWORK').replace('/',' / ').toUpperCase();
  for(const [index,item] of filtered.entries()){
    const button=el('button','art'+(state.selected?.id===item.id?' selected':''));button.setAttribute('aria-label','Inspect '+item.relative);button.setAttribute('aria-pressed',String(state.selected?.id===item.id));
    const frame=el('div','art-visual');const image=el('img');image.alt='Clean artwork '+shortName(item);image.loading='lazy';frame.append(image,el('span','art-index',String(index+1).padStart(2,'0')),el('span','art-check','✓ DATE ONLY'));
    const title=el('div','art-title');title.append(el('span','',shortName(item)),el('span','',bin(item)));button.append(frame,title,el('div','art-date',item.day+' · '+item.width+' × '+item.height));
    button.onclick=()=>select(item.id);button.ondblclick=()=>{select(item.id);setView('lab');};gallery.append(button);loadImage(image,'image/'+item.id+'?thumb=true');
  }
  if(state.images.length&&!filtered.length)gallery.append(el('p','quiet','No images match this filter.'));
}
function renderInspector(){
  const row=state.selected;$('inspector-empty').hidden=!!row;$('inspector-body').hidden=!row;if(!row)return;
  loadImage($('inspect-image'),'image/'+row.id+'?thumb=true');$('inspect-name').textContent=shortName(row);$('inspect-bin').textContent=bin(row);
  const details=$('inspect-details');details.replaceChildren();
  const dateLabels={filesystem_creation:'Creation date',filesystem_modified:'Modified fallback',embedded:'Embedded date'};
  for(const [key,value] of [['Dimensions',`${row.width} × ${row.height}`],['Pixel area',(row.width*row.height/1e6).toFixed(2)+' MP'],['Retained date',row.day],['Date basis',dateLabels[row.date_source]||row.date_source],['Format','Fresh PNG / 8-bit'],['Size',(row.bytes/1024/1024).toFixed(2)+' MiB']]){const div=el('div');div.append(el('dt','',key),el('dd','',value));details.append(div);}
}
async function renderLab(){
  const revision=++labRevision;
  const row=state.selected;
  $('lab-source').textContent=row?shortName(row)+' / '+row.day:'NO ARTWORK SELECTED';
  $('stage-empty').hidden=!!row;$('comparison').hidden=!row;
  $('render').disabled=!row||!!busyJob;$('compare-external').disabled=!row||!!busyJob;
  $('export').disabled=!state.trial||!!busyJob;
  if(!row)return;
  const trial=state.trial;
  const cleanPath=trial?'trial/'+trial.id+'/clean':'image/'+row.id;
  const candidatePath=trial?'trial/'+trial.id+'/'+(state.mode==='difference'?'difference':'candidate'):cleanPath;
  await Promise.all([loadImage($('lab-clean'),cleanPath),loadImage($('lab-candidate'),candidatePath)]);
  if(revision!==labRevision)return;
  $('stage-labels').hidden=!trial;
  applySplit();renderTrialMetrics();
  const strip=$('trial-strip');strip.replaceChildren();
  const list=state.trials.filter(t=>t.image_id===row.id);
  for(const [i,t] of list.entries()){const b=el('button','trial-chip'+(trial?.id===t.id?' selected':''),`CANDIDATE ${String(i+1).padStart(2,'0')} · ${t.epsilon_255? t.epsilon_255+'/255':'EXTERNAL'}`);b.onclick=()=>{state.trial=t;renderLab();};strip.append(b);}
}
function applySplit(){
  let value=Number($('split').value);if(state.mode==='clean')value=100;else if(state.mode==='candidate'||state.mode==='difference')value=0;
  $('candidate-clip').style.clipPath=`inset(0 0 0 ${value}%)`;$('divider').style.left=value+'%';$('divider').hidden=state.mode!=='split';
}
function renderTrialMetrics(){
  const trial=state.trial;const area=$('trial-metrics'),body=$('transport-body');area.replaceChildren();body.replaceChildren();
  if(!trial){area.append(el('span','','NO CANDIDATE YET'),el('p','','A render is an experiment, not a security certificate.'));const tr=el('tr');const td=el('td','','No transport measurements yet.');td.colSpan=4;tr.append(td);body.append(tr);return;}
  for(const [value,label] of [[trial.fidelity.psnr_db===null?'∞':trial.fidelity.psnr_db.toFixed(1),'PSNR / dB'],[trial.fidelity.max_channel_delta_255,'PEAK Δ / 255'],[trial.transport.rows.length,'TRANSPORT TESTS']]){const metric=el('div','metric');metric.append(el('strong','',String(value)),el('small','',label));area.append(metric);}area.append(el('span','','AI PROTECTION\nUNVERIFIED'));
  for(const item of trial.transport.rows){const tr=el('tr');tr.append(el('td','',item.transform),el('td','',item.rmse_255.toFixed(3)),el('td','',String(item.max_channel_delta_255)),el('td','amber','Not tested'));body.append(tr);}
}
async function renderMethods(){
  const area=$('methods');if(area.childElementCount)return;
  try{const data=await api('methods');for(const [i,m] of data.methods.entries()){const row=el('article','method-row');const name=el('div');name.append(el('h3','',m.name),el('small','',m.target));const desc=el('div');desc.append(el('p','',m.evidence));const link=el('a','','PRIMARY SOURCE ↗');link.href=m.source;link.target='_blank';link.rel='noreferrer noopener';desc.append(link);row.append(el('div','number',String(i+1).padStart(2,'0')),name,desc,el('div','status',m.status));area.append(row);}}catch(e){error(e);}
}
function jobFooter(job){$('footer-state').textContent=job.state.toUpperCase();$('footer-detail').textContent=job.phase+(job.total?' · '+job.processed+' / '+job.total:'');}
async function refresh(){
  try{
    const data=await api('state');const changed=JSON.stringify(data.images)!==JSON.stringify(state.images)||JSON.stringify(data.trials)!==JSON.stringify(state.trials);
    state.images=data.images;state.trials=data.trials;
    if(state.selected)state.selected=state.images.find(i=>i.id===state.selected.id)||null;
    if(!state.selected&&state.images.length){state.selected=state.images[0];state.trial=state.trials.find(t=>t.image_id===state.selected.id)||null;}
    $('image-count').textContent=state.images.length+' images';$('nav-count').textContent=state.images.length;$('trial-count').textContent=state.trials.length;
    const running=data.jobs.find(j=>j.state==='running'||j.state==='queued');busyJob=running?.id||null;
    if(running)jobFooter(running);
    for(const job of data.jobs){
      if(['done','error'].includes(job.state)&&!lastJobs.has(job.id)){
        lastJobs.add(job.id);jobFooter(job);
        if(job.state==='error'){error(new Error(job.code));continue;}
        const result=job.result;
        if(result.mode==='READ_ONLY'){$('plan-result').textContent=JSON.stringify(result,null,2);state.plan=true;$('apply').disabled=!$('ack-remove').checked;}
        else if(result.mode==='APPLY'){$('plan-result').textContent=JSON.stringify(result,null,2);toast('Organization checkpoint: '+result.checkpoint);state.plan=false;$('apply').disabled=true;}
        else if(result.image_id){state.selected=state.images.find(i=>i.id===result.image_id);state.trial=result;setView('lab');toast('Candidate ready. AI protection remains unverified.');}
      }
    }
    if(changed){renderTree();renderGallery();renderInspector();if(state.view==='lab')renderLab();}
    $('render').disabled=!state.selected||!!busyJob;$('compare-external').disabled=!state.selected||!!busyJob;
    $('run-plan').disabled=!!busyJob;$('apply').disabled=!!busyJob||!state.plan||!$('ack-remove').checked;
  }catch(e){if(e.message==='SESSION_REQUIRED'){clearInterval(pollTimer);toast('Open the session URL printed by shroud serve to unlock this local workspace.');}else error(e);}
}
async function launch(endpoint,body){try{const result=await api(endpoint,body);busyJob=result.job_id;refresh();}catch(e){error(e);}}
function openOrganize(){ $('organize-dialog').showModal(); }
$('scan').onclick=openOrganize;$('empty-scan').onclick=()=>{openOrganize();$('run-plan').click();};
$('run-plan').onclick=()=>{state.plan=false;$('apply').disabled=true;launch('organize',{date_mode:$('date-mode').value,discard_sidecars:$('discard-sidecars').checked});};
for(const id of ['date-mode','discard-sidecars'])$(id).onchange=()=>{state.plan=false;$('apply').disabled=true;};
$('ack-remove').onchange=()=>$('apply').disabled=!state.plan||!$('ack-remove').checked;
$('apply').onclick=()=>{if(!state.plan||!$('ack-remove').checked)return;launch('organize',{apply:true,acknowledge_source_removal:true,discard_sidecars:$('discard-sidecars').checked,date_mode:$('date-mode').value});$('apply').disabled=true;};
$('audit').onclick=async()=>{try{const r=await api('audit');$('report-title').textContent='Workspace audit';$('report-content').textContent=JSON.stringify(r,null,2);$('report-dialog').showModal();}catch(e){error(e);}};
$('all-folders').onclick=()=>{state.folder='';renderTree();renderGallery();};
$('search').oninput=e=>{state.search=e.target.value.toLowerCase();renderGallery();};
$('open-lab').onclick=()=>setView('lab');
for(const b of document.querySelectorAll('[data-view]'))b.onclick=()=>setView(b.dataset.view);
for(const b of document.querySelectorAll('[data-size]'))b.onclick=()=>{state.size=b.dataset.size;document.querySelectorAll('[data-size]').forEach(x=>x.classList.toggle('selected',x===b));renderGallery();};
for(const b of document.querySelectorAll('[data-inspect]'))b.onclick=()=>{state.mode=b.dataset.inspect;document.querySelectorAll('[data-inspect]').forEach(x=>x.classList.toggle('selected',x===b));renderLab();};
$('epsilon').oninput=()=>$('epsilon-value').textContent=$('epsilon').value+' / 255';
$('split').oninput=applySplit;
$('render').onclick=()=>{if(!state.selected)return;launch('guard',{image_id:state.selected.id,vae_directory:$('vae').value,max_edge:Number($('max-edge').value),epsilon:Number($('epsilon').value),steps:Number($('steps').value),seed:7});};
$('compare-external').onclick=()=>{if(!state.selected)return;launch('compare',{image_id:state.selected.id,candidate_path:$('external-path').value,max_edge:Number($('max-edge').value)});$('external-path').value='';};
$('export').onclick=async()=>{if(!state.trial)return;try{const r=await api('export',{trial_id:state.trial.id,acknowledge_unverified:$('ack-export').checked});$('report-title').textContent='Candidate exported';$('report-content').textContent=JSON.stringify(r,null,2);$('report-dialog').showModal();}catch(e){error(e);}};
window.addEventListener('beforeunload',()=>{for(const url of blobs.values())URL.revokeObjectURL(url);});
refresh();pollTimer=setInterval(refresh,1800);
