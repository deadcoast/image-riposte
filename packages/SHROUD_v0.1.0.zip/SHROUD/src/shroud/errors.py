"""Error codes, never decoder messages, source paths, or source metadata."""
class ShroudError(Exception):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)
