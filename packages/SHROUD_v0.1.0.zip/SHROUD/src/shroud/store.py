from __future__ import annotations
import contextlib
import json
import os
import sqlite3
import uuid
from pathlib import Path
from .errors import ShroudError
from .policy import canonical_path, is_link
from .sanitize import png_audit, timestamp_day

SIGNATURE = 'SHROUD_WORKSPACE_1\n'

def check_root(root: Path) -> Path:
    root = root.absolute()
    if not root.is_dir() or is_link(root):
        raise ShroudError("ROOT_INVALID")
    # Do not follow linked ancestors into a different storage boundary.
    if any(is_link(p) for p in root.parents):
        raise ShroudError("ROOT_LINKED")
    state = root / ".shroud"
    if state.exists():
        if is_link(state) or not state.is_dir():
            raise ShroudError("STATE_PATH_INVALID")
        marker = state / "WORKSPACE"
        try:
            if is_link(marker) or marker.read_text() != SIGNATURE:
                raise ShroudError("STATE_DIRECTORY_CONFLICT")
        except OSError:
            raise ShroudError("STATE_DIRECTORY_CONFLICT") from None
    return root

def state_dir(root: Path) -> Path:
    root = check_root(root)
    state = root / ".shroud"
    if not state.exists():
        state.mkdir(mode=0o700)
        (state / "WORKSPACE").write_text(SIGNATURE)
    return state

def safe_child(root: Path, relative: str) -> Path:
    root = check_root(root)
    path = Path(relative)
    if path.is_absolute() or any(p in {"..", "."} for p in path.parts) or "\\" in relative:
        raise ShroudError("PATH_REJECTED")
    dest = root / path
    if not dest.is_relative_to(root):
        raise ShroudError("PATH_REJECTED")
    cur = root
    for part in path.parts:
        cur = cur / part
        if (cur.exists() or cur.is_symlink()) and is_link(cur):
            raise ShroudError("PATH_LINKED")
    return dest

@contextlib.contextmanager
def workspace_lock(root: Path):
    path = state_dir(root) / "operation.lock"
    if path.exists() and is_link(path):
        raise ShroudError("STATE_PATH_INVALID")
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        raise ShroudError("WORKSPACE_LOCKED") from None
    try:
        os.close(fd)
        yield
    finally:
        path.unlink(missing_ok=True)

def connect(root: Path) -> sqlite3.Connection:
    path = state_dir(root) / "catalog.sqlite3"
    if path.exists() and is_link(path):
        raise ShroudError("STATE_PATH_INVALID")
    db = sqlite3.connect(path, timeout=20)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=DELETE")
    db.execute("PRAGMA secure_delete=ON")
    db.execute("CREATE TABLE IF NOT EXISTS images (id TEXT PRIMARY KEY, relative TEXT UNIQUE NOT NULL, day TEXT NOT NULL, date_source TEXT NOT NULL, width INTEGER NOT NULL, height INTEGER NOT NULL, sha256 TEXT NOT NULL, bytes INTEGER NOT NULL)")
    db.commit()
    return db

def catalog(root: Path) -> list[dict]:
    check_root(root)
    if not (root / ".shroud/catalog.sqlite3").exists():
        return []
    with contextlib.closing(connect(root)) as db:
        result = [dict(row) for row in db.execute("SELECT * FROM images ORDER BY day DESC, relative")]
    for row in result:
        canonical_path(row["relative"])
    return result

def record_image(root: Path, relative: str, audit: dict, size: int, date_source: str) -> dict:
    canonical_path(relative)
    row = {"id": uuid.uuid4().hex, "relative": relative, "day": audit["date"],
           "date_source": date_source, "width": audit["width"], "height": audit["height"],
           "sha256": audit["sha256"], "bytes": size}
    with contextlib.closing(connect(root)) as db:
        db.execute("INSERT INTO images VALUES (:id,:relative,:day,:date_source,:width,:height,:sha256,:bytes)", row)
        db.commit()
    return row

def find_image(root: Path, identifier: str) -> dict:
    if len(identifier) != 32 or any(c not in "0123456789abcdef" for c in identifier):
        raise ShroudError("IMAGE_NOT_FOUND")
    for row in catalog(root):
        if row["id"] == identifier:
            path = safe_child(root, canonical_path(row["relative"]))
            try:
                result = png_audit(path.read_bytes())
            except OSError:
                raise ShroudError("CATALOG_FILE_MISSING") from None
            if result["sha256"] != row["sha256"]:
                raise ShroudError("CATALOG_FILE_CHANGED")
            return row
    raise ShroudError("IMAGE_NOT_FOUND")

def atomic_clean_write(root: Path, relative: str, data: bytes, replace: bool = False) -> Path:
    audit = png_audit(data)
    dest = safe_child(root, relative)
    if dest.exists() and not replace:
        raise ShroudError("DESTINATION_EXISTS")
    dest.parent.mkdir(parents=True, exist_ok=True)
    # All temporary bytes are already canonical and contain only the retained date.
    temp = dest.parent / (".clean-" + uuid.uuid4().hex + ".tmp")
    try:
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        if dest.exists() and not replace:
            raise ShroudError("DESTINATION_EXISTS")
        os.replace(temp, dest)
        timestamp_day(dest, audit["date"])
        if png_audit(dest.read_bytes())["sha256"] != audit["sha256"]:
            raise ShroudError("WRITE_VERIFY_FAILED")
        return dest
    finally:
        temp.unlink(missing_ok=True)

def write_report(root: Path, name: str, report: dict) -> None:
    # Only callers with explicit, code-defined schemas call this function.
    if name not in {"last-run.json", "last-audit.json"}:
        raise ShroudError("REPORT_NAME_INVALID")
    path = state_dir(root) / name
    if path.exists() and is_link(path):
        raise ShroudError("STATE_PATH_INVALID")
    temp = path.with_suffix(".tmp")
    if temp.exists() and is_link(temp):
        raise ShroudError("STATE_PATH_INVALID")
    temp.write_text(json.dumps(report, indent=2, allow_nan=False))
    os.replace(temp, path)
