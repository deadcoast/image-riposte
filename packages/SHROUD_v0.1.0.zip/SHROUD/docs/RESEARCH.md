# Image-integrated protection: research and implementation decisions

**Reviewed 14 September 2026.** Primary publications and official project documentation only. A method being listed here does not mean its code is installed, its license permits redistribution, or its claims have been reproduced in SHROUD.

## 1. The threat is not one thing

A model can describe an image, use its composition as a reference, edit its pixels, learn a style from a collection, or animate a single frame. A defense optimized for one pathway need not disrupt the others. SHROUD therefore treats recognition, reference-driven generation, editing, style learning, and video conditioning as separate evaluation targets.

The artist's constraint is also explicit: the published raster must remain an acceptable illustration. There is no watermark payload, hidden authorship code, viewer-side account, or expectation that an external model obey a “do not train” instruction. The mechanism under investigation is a **calculated change to the pixels consumed by the model**.

The system must not rename generic noise “protection.” It must also not interpret a parser failure, unreadable image, extreme distortion, or merely different generated output as successful protection. Those outcomes can fail the artist's requirement even when a numerical attack metric improves.

## 2. Methods worth distinguishing

| Method | Mechanism and relevant target | SHROUD decision |
|---|---|---|
| **Glaze** | Image-specific feature displacement aimed at learning an artist's style. The official FAQ expressly distinguishes this from unreliable img2img protection. | An external-candidate path for style experiments; not the default editing/video engine. [Official FAQ](https://glaze.cs.uchicago.edu/faq.html) |
| **Nightshade** | Prompt-specific poisoning intended to influence later model training on the processed examples. | A separate training-data research track; not immediate protection against an already-trained image editor. [Paper](https://arxiv.org/abs/2310.13828) |
| **PhotoGuard** | Encoder-directed and end-to-end diffusion perturbations for editing resistance. | A useful editing baseline and reason to test the full generator rather than stop at encoder features. SHROUD's baseline is not a reproduction. [Paper](https://arxiv.org/abs/2302.06588) · [Official code](https://github.com/MadryLab/photoguard) |
| **Mist / Mist v2** | Adversarial preprocessing targeting mimicry and editing. Its own documentation uses watermark terminology. | No bundled default under the no-watermark constraint. Review the mechanism and distribution terms before adapting it; the repository's licensing language is ambiguous. [Official repository](https://github.com/psyker-team/mist-v2) |
| **DiffusionGuard** | Early-diffusion attack objective and mask augmentation, aimed at mask-guided editing. | High-priority candidate for the next editing backend. Its objective is more directly tied to editing than an encoder-only score. [Paper](https://arxiv.org/abs/2410.05694) · [Official code](https://github.com/choi403/DiffusionGuard) |
| **DCT-Shield** | Adversarial optimization in discrete-cosine-transform coefficients, with compression robustness as a central concern. | Relevant to a JPEG-aware backend. SHROUD currently uses a differentiable JPEG surrogate, not this method's implementation. [Paper](https://arxiv.org/abs/2504.17894) |
| **I2VGuard** | Spatial, temporal, and diffusion attack components for misuse of a still image by image-to-video systems; CVPR 2025. | A substantive video-defense implementation target, requiring generated-video evaluation rather than single-frame inspection. [CVPR paper](https://openaccess.thecvf.com/content/CVPR2025/html/Gui_I2VGuard_Safeguarding_Images_against_Misuse_in_Diffusion-based_Image-to-Video_Models_CVPR_2025_paper.html) |
| **Vid-Freeze** | Suppresses video motion through an attention-oriented objective. | A distinct outcome: preventing useful animation is not the same as preventing recognition of the illustration. Keep both measurements. [Paper](https://arxiv.org/abs/2509.23279) |
| **Anti-Prompt** | July 2026 paper examining text conditioning and attacking text-related interactions during video denoising; its arXiv record reports ECCV 2026 acceptance. | A current text-guided-video research candidate, not an established production winner. [Paper](https://arxiv.org/abs/2607.01499) |
| **I2VShield** | July 2026 preprint proposing a text-adaptive perturbation generator and multimodal-attention disruption for diffusion-transformer video models. | Investigate scalable per-image rendering after independent reproduction. Code readiness and deployment performance are not established by this release. [Paper](https://arxiv.org/abs/2607.25522) |

### Conflicting evidence must remain visible

The Glaze project claims transfer and resistance to common preprocessing. An independent style-mimicry evaluation reports that the protections it tested could be weakened by adaptive approaches including image upscaling. These are not grounds to assert that every later implementation is broken—or that every current cloak is reliable. They require version-specific, adversarial evaluation. [Glaze FAQ](https://glaze.cs.uchicago.edu/faq.html) · [Hönig et al.](https://arxiv.org/abs/2406.12027)

The **August 19, 2026 revision of IPV-Bench** compares five defenses across four video models and reports weak transfer, frequent failure to outperform noise, and preprocessing failures in effective cases. Its older title was IP-Bench; the current revision must not be described using the older version's model/method counts. This is a benchmark result for the tested methods, not a proof that further development cannot improve defenses. [IPV-Bench v3](https://arxiv.org/abs/2603.26154v3)

## 3. What this research changes in the product

**No single “protection strength” percentage.** One candidate can be visually acceptable, alter an encoder strongly, survive compression, and still produce an excellent copied animation. Those observations belong in separate fields.

**Do not stack filters blindly.** Successive optimizations can spend the same visual budget, destroy an earlier perturbation, or target incompatible pathways. A stronger design optimizes a shared final raster against multiple objectives, then evaluates the combined result. The relative weights must be justified by held-out performance, not by the number of techniques named in the interface.

**Optimize the actual publication representation.** Flattening transparency, resizing, quantization, compression, and platform conversion are part of the path to the attacker. Protection calculated for a 4000-pixel master is not automatically evidence about its 1080-pixel social derivative. The current lab standardizes the public raster before optimization and tests it after real codec operations.

**Keep meaningful negative controls.** Compare the clean image, a matched random-noise control, a visually comparable non-adversarial alteration, and the calculated candidate. A perturbation should outperform a quality-matched control on the actual misuse task. Merely changing a generator's random trajectory is not enough.

**Separate optimization and evaluation.** Never optimize against all images, prompts, masks, seeds and models and call that a transfer test. Reserve held-out illustration styles and at least one architecture outside the optimizer. Record unsuccessful cases with the same visibility as successes.

These are SHROUD design decisions informed by the distinctions and evaluations above, not claims of a newly proven defense.

## 4. Built now: a measurable baseline

SHROUD EOT-VAE uses projected gradient updates to maximize an adaptive soft minimum of normalized latent divergence across one or more local VAEs and several transforms. Its final raster has a strict 8-bit per-channel budget, a white-canvas mask, and a reduced edge budget. A quantization-aware forward pass prevents optimizing only fractional values that vanish on export.

This establishes an executable optimization baseline, a fidelity budget, and an evaluation path. It does **not** establish semantic-recognition failure, style-learning failure, image-edit failure, or animation failure. The UI calls its evidence `ENCODER_PROXY_ONLY`. The local VAE loading API follows the [official AutoencoderKL interface](https://huggingface.co/docs/diffusers/en/api/models/autoencoderkl).

A separate paired-generation runner targets reference [Stable Diffusion img2img](https://huggingface.co/docs/diffusers/en/api/pipelines/stable_diffusion/img2img) and [Stable Video Diffusion](https://huggingface.co/docs/diffusers/en/api/pipelines/stable_diffusion/svd) pipelines. These are baseline adapters. Full-weight operation was not validated in the delivery environment; generation differences are not automatically scored as protection.

## 5. The next experiment should answer a concrete question

> On acceptable-quality illustrations after the actual publishing transform, does the candidate reduce a specified misuse task's success more than a matched perturbation control—and does that result transfer beyond the optimizer's model?

A proposed evaluation set should include line art on white, flat/cel shading, textured illustration, subtle gradients, fine hatching, and small-format samples. Each image needs an artist-acceptable visual budget rather than an assumed universal imperceptibility threshold.

For editing, vary masks, preservation instructions and editing strength. Review whether recognizable source composition and characteristic details survive the intended edit. For reference generation, test whether distinctive design elements survive re-prompting. For video, review source fidelity, meaningful motion, instruction following, temporal consistency and useful output quality separately. A frozen frame is a motion-specific result, not evidence that the model cannot perceive the image.

Apply the transformations an attacker could plausibly use: actual published/downloaded file pairs, screenshots at different scales, crop/resampling, JPEG/WebP transcoding, denoising and upscaling. The first release implements a smaller generic transport suite; it does not claim that suite fully reproduces platform processing or adaptive removal.

Model versions, safe model identifiers/fingerprints, code version, seeds, prompts, masks, transform parameters, quality reviews and clean-output hashes are necessary before a reproducible protection claim. No source-image metadata or raw image-path history is needed to record those experiments.

## 6. Integration order

First qualify the existing VAE baseline against real editing outputs and measured social derivatives. Then implement a joint early-diffusion/mask objective and evaluate a frequency-constrained variant. Next add a genuine temporal or attention-based video objective with text-guided held-out models. Only after those results justify it should a faster perturbation generator, broad batch rendering, and platform-specific profiles become product defaults.

This sequence keeps development focused on whether copying actually becomes harder, rather than decorating the interface with untested defense names. Audience friction and watermarks are excluded throughout.
