# SHROUD — development specification

**Release:** 0.1.0 · **Status:** implemented foundation plus experimental model-dependent protection lab.

## Product purpose

Prepare an artist's own illustrations for public display without viewer authentication or watermarking, while minimizing metadata exposure and developing measurable resistance to AI-mediated reuse. Source cleanliness, acceptable appearance, and demonstrated model-specific resistance are independent requirements. Passing one cannot compensate for failing another.

## Non-negotiable contracts

1. **Metadata contract:** every managed image and generated image artifact is rebuilt as an audited date-only PNG. Never persist raw image metadata, source bytes, source hashes, original filenames, original folder paths, or original metadata-bearing thumbnails.
2. **Organization contract:** use the requested year roots, English months, fixed pixel-area categories and collision-safe names. Create only needed directories. All existing content in the selected artwork root is in scope except the application's validated reserved state directory.
3. **Mutation contract:** default scans are read-only. Apply is explicit. Write and verify a new canonical image before unlinking its source. Do not preserve contaminated originals in an automatic backup, quarantine or Trash. On uncertainty, retain the unprocessed source and report `INCOMPLETE`; never manufacture a clean checkpoint.
4. **Protection contract:** no watermark payload, generic-noise fallback, audience gate, automated cloud upload, or universal-success claim. A model-derived candidate is still experimental until measured on the intended misuse task and publishing path.
5. **Evidence contract:** display fidelity, transport, model-proxy behavior, actual generation outcomes and review judgment separately. Do not convert surrogate divergence into a probability of protection.

## Requirement coverage

| User requirement | Implemented behavior | Boundary |
|---|---|---|
| Size/quality categories per month | Fixed pixel-area bins and displayed dimensions/bytes | Resolution is measured; artistic quality is not inferred |
| 2026 / 2025 / 2024 / other years | Exact roots, exact retained date | Other-year January files share one January directory |
| English month names; no empty scaffolding | Lazy folder creation, chronological UI tree | Native file managers may alphabetize names |
| Reconcile existing layouts | Recursive content-sniffed migration, canonical renaming, collision handling | Links, unknown files and unsupported formats require review |
| Date is sole retained image metadata | Fresh pixels, orientation/color handling, strict PNG audit | Structural encoding data is necessary to display an image |
| Remove location data and hidden container data | No copied EXIF/XMP/comments/profiles; no raw backups; no trailing/compressed tail data; invisible RGB zeroed | Not a pixel-steganography detector or disk-forensic eraser |
| Cleanup before protection | Complete workspace audit gates candidate creation/import | No claim of an adversarial filesystem-race sandbox |
| Image-integrated anti-AI methods | Actual multi-VAE EOT optimization and external-candidate path | Pretrained/GPU effectiveness unverified |
| Editing and video | Optional paired baseline runners and separate research tracks | No built-in temporal defense or current proprietary-model guarantee |
| Visual application | Local library, inspector, lab, divider, delta view, transport table, evidence register | No batch protection selection in the first UI |
| Third-party packages | Declared core/lab/test dependencies, local-only model loading | Dependencies and model licenses remain separate obligations |

## Architecture and source navigation

| Module | Responsibility |
|---|---|
| `policy.py` | Date policy, size categories, format limits and canonical naming |
| `sanitize.py` | Decode, orientation/color application, fresh raster, encoding and independent container audit |
| `store.py` | Safe relative paths, workspace identity, operation lock, clean atomic writes and minimal catalog |
| `organizer.py` | Read-only plan, migration, residual checks and checkpoint audit |
| `metrics.py` | Paired real-codec transforms, fidelity measurements, difference visualization |
| `optimizer.py` | Quantization-aware PGD, image budget masks, transform surrogate and local VAE adapter |
| `lab.py` | Clean public raster, candidate import/render, trial records and export |
| `benchmark.py` | Optional paired editing/video baseline execution and sanitized outputs |
| `server.py` | Loopback API, transient session token, job queue and sanitized image access |
| `cli.py` | Explicit commands and machine-readable results |
| `static/` | Self-hosted HTML/CSS/JavaScript; no external assets or analytics |
| `methods.json` | Source-linked research register, including integration boundaries |

### Pipeline

```text
read-only scan
    └─ classify by decoder, date and dimensions
         └─ explicit apply
              └─ decoded pixels → orientation/color → fresh raster
                   └─ date-only PNG → audit → verified commit
                        └─ catalog clean output → unlink unchanged source
                             └─ rescan → COMPLETE or INCOMPLETE

COMPLETE checkpoint
    └─ clean master → public-size RGB raster
         ├─ model-dependent optimization
         └─ external candidate → sanitize and match dimensions
              └─ clean/candidate paired transforms
                   └─ inspect fidelity and surviving differences
                        ├─ optional paired generation/review
                        └─ explicit unverified export → audited PNG
```

The catalog stores a random asset ID, canonical relative path, retained day, date-basis enum, dimensions, encoded byte count, and a hash computed from the clean output. It never needs an original-input fingerprint. Failed-source references exist only transiently while processing; persistent failures are aggregate codes and counts.

## Canonical image profile

Output is non-interlaced RGB8 or RGBA8 PNG. Allowed chunks: `IHDR`, `IDAT`, `IEND`, and exactly one `tEXt` entry named `Creation Time` with a valid `YYYY-MM-DD` value. Audit verifies chunk CRCs and bounds, permitted color type/bit depth, decoded information, exact decompressed raster length, no hidden compressed tail, no trailing bytes, and zero RGB under fully transparent alpha.

Valid source profiles are applied before being discarded. Original color-profile metadata is not retained. Masters keep their dimensions and alpha. Public candidates are flattened on white, downscaled only when needed, and rebuilt again. User approval of appearance remains necessary; numerical fidelity is not an artistic-quality oracle.

Files are capped at 512 MiB and 60 million pixels. High-bit/HDR, multi-frame/layered and unsupported inputs stop rather than undergo undocumented lossy conversion. This profile is deliberately narrower than “all images accepted.” Broader codec support must preserve the same checkpoint and no-silent-loss properties.

## Date and layout rules

`download` means birth/creation time when the platform exposes it, otherwise modified time with a recorded fallback. `modified` is explicit filesystem modification time. `embedded` selects supported embedded date fields before the fallback. No guessed timestamp is invented from an ambiguous filename.

Use pixel area `p = width × height`: SML for `p < 10^6`; MED for `10^6 ≤ p < 4×10^6`; LRG for `4×10^6 ≤ p < 16×10^6`; XTL otherwise. These same thresholds apply in every month. Limits still cap admissible images. Naming uses the next available category suffix, padded to at least two digits. Gaps need not be filled and existing clean assets must not be renumbered simply for cosmetic compactness.

## Optimization already implemented

Let `x` be the normalized public RGB raster and `Q` the 8-bit quantizer. Construct a spatial budget `b(x)` from an integer channel budget, a white-canvas mask and a reduced high-contrast-edge mask. Admissible candidates satisfy:

```text
0 ≤ y ≤ 1
|y − x| ≤ b(x)
Q(y) is the image actually evaluated and exported
```

For encoder `E_m` and transform `T_k`, the implemented score is:

```text
d_mk(y) = mean((E_m(T_k(Q(y))) − E_m(T_k(x)))²)
          / max(mean(E_m(T_k(x))²), 10⁻⁶)

F(y) = −τ log(mean(exp(−d_mk(y)/τ)))
```

The temperature is the detached mean divergence, floored at `10⁻⁶`, at each iteration. Signed-gradient ascent is projected back into the local budget. Straight-through rounding supplies the quantizer's optimization gradient. The transform set is identity, resample, centered crop and a block-DCT/JPEG approximation. Multiple encoders can be supplied through the CLI. This is an adaptive soft-worst-case **proxy objective**, not a calibrated success probability.

The default channel budget is `4/255`, not a claim of invisibility. The allowed range is 1–16 integer channel levels. The final encoded pixels are checked against the original public raster. The JPEG surrogate uses 4:4:4 YCbCr DCT quantization; actual evaluation independently uses real 4:2:0 JPEG encoding. Surrogate and evaluation transforms are intentionally not described as identical.

**Current optimization boundary:** only latent means are attacked. There is no built-in CLIP/vision-language semantic objective, full-diffusion defense objective, style-training objective, or temporal-defense objective. No upstream defense's reported results attach to this implementation.

## Evidence states

| State | What is established | What is not established |
|---|---|---|
| `DATE_ONLY` | Canonical metadata/container checks passed | Anti-copy or anti-AI protection |
| `PIXEL_TRANSPORT_ONLY` | Paired pixel measurements after stated transforms | Model or generation failure |
| `ENCODER_PROXY_ONLY` | A candidate was optimized against local encoder features | Editing, style or video resistance |
| `PAIRED_GENERATIONS_UNSCORED` | Matched runs produced outputs for review | A validated judgment that misuse failed |
| Future scoped qualification | Named task/model/version/transform evaluation and quality acceptance | Universal protection or future-model guarantees |

This release never emits “verified AI protection.” Explicit acknowledgment permits exporting an experimental candidate; it does not upgrade its evidence state. Trial reports store only clean-derived references, code-defined numerical values, random IDs and fixed method labels.

## Editing/video runner contract

Clean and candidate inputs share seeds and transform choices. Input hashes are checked against the trial. Stable Diffusion img2img is an editing baseline; Stable Video Diffusion is an image-conditioned video baseline. Both use local safetensors model loading. Output frames are rebuilt through the same sanitation code; no raw generated container metadata is retained.

The runner measures paired output differences and leaves success judgment to review. Stub tests establish serialization, control flow, matched seeds, hash checks and privacy behavior—not that real models loaded or a defense worked. Full model fingerprints, frozen evaluation manifests, broader prompt/mask sets and independent reviewers are prerequisites for later evidence promotion. Current baseline families are not a coverage claim about proprietary products.

## Interface requirements

Use the art as the primary content: a dense contact sheet, legible inspector and large image comparison stage. Keep controls adjacent to their effects. The source-removal gate must be distinct from the experimental-export acknowledgment. A model path is an operator-selected local resource, never an automatic cloud upload. External-candidate paths are cleared from their form after submission and are not stored in the catalog.

Never replace a failed model request with a visually plausible render. Never show a static mock catalog as live user data. The distributed demo is generated only by an explicit test script in an external temporary folder. It is not loaded into a user's workspace at launch.

## Failure and recovery

A clean output is verified before source removal; a second source stat check avoids knowingly deleting a changed source. Per-workspace locking prevents two SHROUD writes from running concurrently. Reparse points, symlinks and hardlinked inputs stop. This is not a transactional filesystem snapshot and is not hardened against hostile, simultaneous mutation by another local process.

A crash can leave a sanitized output and an unprocessed source, or a stale operation lock. It must not silently erase the original as “recovery.” Stop other instances, inspect the folder, remove a stale lock only after confirming no operation is running, and rescan. An incomplete state remains incomplete. There is no raw source-path recovery journal because preserving it would violate the chosen data-minimization contract.

## Next substantive milestones and acceptance gates

### A. Qualify the existing integrated baseline

Run on the actual target machine and a representative illustration corpus. Freeze model weight fingerprints, package versions and evaluation manifests without raw input metadata. Confirm the local VAE and generation integrations. Measure wall time, VRAM and fidelity at multiple public sizes. Compare candidates with quality-matched noise controls, withheld seeds and actual platform derivatives.

**Gate:** repeatable generation-level evidence and artist-approved quality; failures recorded. Passing code tests alone does not qualify the defense.

### B. Build a coupled editing defense

Implement an early-diffusion/mask objective and a frequency-constrained alternative behind one shared output-budget interface. Optimize the final public raster jointly; do not simply run unrelated filters sequentially. Add holdout masks, prompts, editing strengths and at least one unseen encoder/model family.

**Gate:** a meaningful, reviewed reduction in the defined reuse task beyond matched controls after transport. Reject a candidate that “wins” only by visibly degrading the artwork. Paper-specific method names require faithful, licensed reproduction and separate results.

### C. Add an actual video-defense objective

Implement a temporal or multimodal-attention target with text-guided conditioning, not merely a still-image encoder attack relabeled for video. Evaluate motion, source preservation, instruction compliance and useful video quality separately. Include held-out architecture tests and straightforward removal attempts.

**Gate:** scoped, reproducible video results that survive the relevant public-image path. A motion-specific result must remain labeled as such.

### D. Productize only the useful methods

Introduce cancellation/resume for expensive batches, model capability/VRAM preflight, model hash caching, GPU smoke tests, native Windows/macOS validation, perceptual metrics and human-review queues, measured social profiles, more codecs with explicit fidelity contracts, and process-isolated decoding. Add reproducible dependency locks and distribution signatures once platform-qualified builds exist.

**Gate:** evidence-backed defaults, maintained no-location persistence tests, crash/recovery tests, bounded resource behavior, and a source-to-installed-package release audit. The current release is a coherent development foundation, not a completed cross-platform security certification.
