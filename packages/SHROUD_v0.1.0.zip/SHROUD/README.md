# SHROUD
### Local artwork sanitation, organization, and adversarial-image laboratory

**Version 0.1.0 — first executable release.** No watermark, account, audience authentication, cloud processing, telemetry, or automatic model downloads. This is a local application with a browser interface and a command-line interface.

The cleanup and organizer are implemented and tested. The protection lab contains an actual, model-dependent adversarial optimizer, not a generic noise filter. **AI protection remains unverified:** a working optimizer, changed encoder features, and surviving pixel differences do not establish that an editor or video generator cannot reuse the image. Pretrained-model and CUDA integration were not executable in the delivery environment. See [validation](docs/VALIDATION.md).

## Start on Windows

Extract this project somewhere separate from your artwork. Install Python 3.11 or newer; Python 3.13 was used for this release. From PowerShell in the extracted project:

```powershell
.\START.ps1 -ArtworkFolder "D:\Artwork\SocialSamples"
```

The launcher creates a project-local virtual environment on first use, installs the core package, and opens the local interface. Installation needs network access to the Python package index. It does not organize or delete artwork merely by launching. The artwork folder must already exist.

Manual alternative, including when local script policy prevents using the launcher:

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install .
.\.venv\Scripts\python.exe -m shroud serve "D:\Artwork\SocialSamples"
```

The private session address prints in the terminal and normally opens automatically. Keep the terminal running; Ctrl+C stops the server. Only loopback is bound. The session token protects your local controls; it is not an authentication requirement for anyone viewing your published artwork.

On macOS/Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install .
.venv/bin/python -m shroud serve "$HOME/Artwork/SocialSamples"
```

**Choose a dedicated artwork folder, not your home directory, Downloads root, project directory, virtual environment, or model directory.** All contents of the chosen folder are in scope. Put models and the application elsewhere. Unknown files prevent a complete cleanup checkpoint rather than being silently ignored or deleted.

## First operation: scan, inspect, apply

Click **Scan & organize**, select the date basis, and run the read-only preview. Review the destination counts and blocker codes. The source-removal confirmation must be selected before Apply becomes available.

Or use the CLI:

```powershell
# Read-only: no files or folders created in a fresh workspace.
.\.venv\Scripts\python.exe -m shroud organize "D:\Artwork\SocialSamples"

# Explicitly authorize verified source replacement and known metadata-sidecar removal.
.\.venv\Scripts\python.exe -m shroud organize "D:\Artwork\SocialSamples" --apply --discard-sidecars

# Independent metadata/organization checkpoint.
.\.venv\Scripts\python.exe -m shroud audit "D:\Artwork\SocialSamples"
```

**`--apply` removes each successfully migrated original after a fresh, sanitized PNG has been written and verified. No raw originals are copied to a backup, quarantine directory, or Trash.** This is intentionally destructive to original metadata and filenames. Cleaned masters remain. Unsupported, changing, or failed inputs are not deleted; the checkpoint stays `INCOMPLETE`. Inspect a representative set before a large migration.

`--discard-sidecars` additionally authorizes deletion of `.xmp`, `.exif`, `.iptc`, `.aae`, `.DS_Store`, `Thumbs.db`, and `desktop.ini` files encountered in this dedicated artwork scope. Their contents are not retained. Without authorization they are blockers.

### Your directory scheme

```text
SocialSamples/
├── 2026/
│   └── September/
│       ├── SML/
│       │   └── SML01.png
│       └── LRG/
│           └── LRG01.png
├── 2025/
│   └── December/
│       └── MED/
│           └── MED01.png
└── .shroud/
    ├── WORKSPACE
    ├── catalog.sqlite3
    ├── last-run.json
    ├── lab/                 # Created only after a trial exists.
    ├── benchmarks/          # Created only after a benchmark produces output.
    └── exports/             # Created only after an explicit export.
```

The diagram is illustrative, not a folder template. Only needed year/month/size directories exist. Year roots are exactly `2026`, `2025`, `2024`, and `EVERYTHING_ELSE`; other years share the last root, with their exact dates retained inside files. English month names are displayed in calendar order in the application. Files are never classified by extension.

| Category | Total pixels, width × height | Example |
|---|---:|---|
| SML | Below 1,000,000 | 800 × 800 |
| MED | 1,000,000 to below 4,000,000 | 1600 × 1600 |
| LRG | 4,000,000 to below 16,000,000 | 3000 × 3000 |
| XTL | 16,000,000 or more | 5000 × 5000 |

These are consistent **resolution** categories, not judgments of artistic quality, sharpness, or AI resistance. Byte size is displayed separately. Filenames are collision-safe `SML01.png`, `SML02.png`, etc.; numbering expands beyond 99. Known, unchanged, clean catalog files are not renamed or re-encoded on repeated runs. Empty former directories are removed.

### Date behavior

Default `download` uses filesystem creation/birth time when available; otherwise it uses modified time and records that fallback. Filesystems do not always preserve the actual download date. This is not silently presented as known download history. `--date-mode modified` explicitly uses modified time. `--date-mode embedded` prefers supported embedded date fields before falling back.

The retained value is only `YYYY-MM-DD`: no time of day, timezone, camera serial, author, GPS, thumbnail, software name, comment, or source filename. The date-basis label is local catalog information, not image metadata.

## What the cleansing operation actually does

It decodes the visible raster, applies EXIF orientation, converts a usable source color profile to sRGB, rebuilds a fresh RGB/RGBA image, and writes a new 8-bit PNG. It does not edit an old EXIF structure in place. RGB values concealed behind fully transparent pixels are zeroed. A second reader verifies chunk types, CRCs, the date field, decompression bounds, invisible RGB, and absence of trailing data.

Only structural PNG chunks and one `Creation Time` date field are permitted. Embedded profiles, thumbnails, EXIF, XMP, comments and unknown ancillary chunks do not survive. Only **clean-output** hashes enter the catalog; raw source hashes, raw filenames, original paths and metadata dumps are never recorded by the application.

Fresh PNG is the intentional uniform output format in this release; this is not a type-based folder scheme. Existing JPEG samples are decoded once and saved without another lossy JPEG encoding. Clean masters keep their native dimensions and transparency. Public lab candidates are flattened on white and may be downscaled to the selected maximum edge; they are never upscaled.

Supported inputs: single-frame, supported 8-bit PNG, JPEG, WebP, BMP, TIFF, and GIF, identified by decoder content. High-bit-depth/HDR inputs, animations, layered project formats such as PSD, SVG, HEIC/AVIF/JXL, invalid color profiles, untagged CMYK/LAB, files above 512 MiB, and images above 60 million pixels require review. A failed input is not advertised as clean. Loss of layers, frames, bit depth, or color fidelity is not silently accepted.

This does **not** prove removal of information encoded in visible artwork or arbitrary pixel steganography. It does not erase other copies, SSD recovery data, operating-system caches, shell history, swap or backups. See [threat boundaries](docs/THREAT-MODEL.md).

## The protection lab

Select an image and open the lab. The working controls provide a before/after divider; clean, candidate and amplified-difference views; resolution and pixel-budget controls; a trial history; external-candidate import; transport measurements; and date-only export. A complete organization checkpoint is required before creating or importing a candidate.

### Built-in experiment: EOT-VAE

The optimizer changes pixels using gradients through one or more local variational autoencoders. It optimizes an adaptive soft minimum of normalized feature divergence across identity, resampling, a differentiable JPEG approximation, and a crop. Forward passes include 8-bit quantization. White canvas is held fixed where the mask applies, high-contrast boundaries have reduced budgets, and the final PNG must respect the requested per-channel limit.

It needs real local model weights. **There is no “model unavailable → add random noise” fallback.** The implementation is an original experimental baseline, not a reproduction or bundled version of Glaze, PhotoGuard, DiffusionGuard, DCT-Shield, or an image-to-video defense.

Install the optional dependencies deliberately:

```powershell
.\.venv\Scripts\python.exe -m pip install ".[lab]"
```

For NVIDIA acceleration, install a compatible PyTorch/CUDA build following the [official selector](https://pytorch.org/get-started/locally/) before installing the other optional dependencies. Python package installation is not a model-weight download. A local VAE folder must already contain its `config.json` and `.safetensors` weights. Local-only loading is enforced; pickle model checkpoints and remote custom code are not part of the loading contract. Some model distributions use a nested `vae` directory—select that directory, not an unrelated model root.

List catalog IDs, then run an experiment:

```powershell
.\.venv\Scripts\python.exe -m shroud list "D:\Artwork\SocialSamples"
.\.venv\Scripts\python.exe -m shroud guard "D:\Artwork\SocialSamples" IMAGE_ID --vae "D:\Models\local-model\vae" --max-edge 1536 --epsilon 4 --steps 48
```

The capitalized identifiers in these examples must be replaced with IDs returned by `list` or a trial result. Multiple `--vae` arguments enable an ensemble in the CLI. The UI currently exposes one VAE directory. CPU fallback exists for the optimizer; large images can be impractically slow. CUDA hardware compatibility and performance were not measured in this release.

### External tools and transport tests

An image processed by another local tool can be imported for comparison. It is cleansed again; only its decoded pixels are copied. Its dimensions must match the selected public render of the clean master. The original external file is read-only and remains outside the workspace unchanged.

```powershell
.\.venv\Scripts\python.exe -m shroud compare "D:\Artwork\SocialSamples" IMAGE_ID "D:\Candidate\processed.png" --max-edge 1536 --method external
```

Real Pillow operations test identity; JPEG qualities 95, 85, and 70; 75% resize; 90% crop; radius-0.6 blur; and resize followed by JPEG. Each transform is applied to **both** the clean image and the candidate. Measurements show fidelity and remaining differences, not the probability that copying will fail. The optimizer's JPEG approximation is 4:4:4; these real-codec evaluations use 4:2:0. These generic tests are not verified replicas of particular social platforms.

External-tool names are labels, not assertions that the upstream method was run correctly. The evidence register contains 12 primary-source records, not 12 installed protection engines.

### Paired editing/video runner

Optional CLI code can run paired clean/candidate experiments using a local Stable Diffusion img2img pipeline or Stable Video Diffusion pipeline. They are baseline integrations, not a claim of coverage of current proprietary systems or newer architectures. The runner uses matched seeds, saves date-only frames, and deliberately has no automatic “protected” score.

```powershell
.\.venv\Scripts\python.exe -m shroud benchmark "D:\Artwork\SocialSamples" TRIAL_ID --model "D:\Models\local-sd-pipeline" --task edit
.\.venv\Scripts\python.exe -m shroud benchmark "D:\Artwork\SocialSamples" TRIAL_ID --model "D:\Models\local-svd-pipeline" --task video
```

This runner requires CUDA. The video baseline is image-conditioned; its evaluation does not establish resistance to text-guided video models. Its control flow was tested using stub generators, **not full pretrained pipelines**. Outputs are marked `PAIRED_GENERATIONS_UNSCORED` and `UNVERIFIED` until independently reviewed. Generating a different output is not necessarily preventing misuse.

### Export

Select the explicit acknowledgment in the UI or use:

```powershell
.\.venv\Scripts\python.exe -m shroud export "D:\Artwork\SocialSamples" TRIAL_ID --acknowledge-unverified
```

The export is `.shroud/exports/TRIAL_ID/candidate.png` under the artwork folder. It contains the candidate pixels and retained date, not the lab report. Re-encoding or changing dimensions after protection can change its behavior; transport tests need to follow the actual publishing path. No automatic social upload is performed.

## Development and evidence

- [Research dossier](docs/RESEARCH.md): methods, threat separation, conflicting evidence, and integration priorities.
- [Development specification](docs/DEVELOPMENT-SPEC.md): contracts, implementation map, optimization objective, and acceptance gates.
- [Threat model](docs/THREAT-MODEL.md): exact meaning of “clean,” failure behavior, and remaining boundaries.
- [Validation](docs/VALIDATION.md): executed tests, browser harness, package checks, and untested integrations.

```bash
python -m pip install ".[test]"
python -m pytest -q
```

The optimizer and runner control-flow tests additionally need PyTorch; they skip when it is absent. Browser QA uses the optional Playwright test tool and Chromium. The included screenshots use original synthetic geometric fixtures; the sample external candidate is a random-noise **negative/control fixture**, never presented as effective protection. No user's real artwork was available or processed during this build.
