"""Run against a temporary synthetic fixture workspace, not real personal files."""
import json
import argparse
import base64
from pathlib import Path
from playwright.sync_api import sync_playwright

def run(output:Path, root:Path|None=None):
    output.mkdir(parents=True,exist_ok=True)
    issues=[];checks=[]
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1512,'height':1060},device_scale_factor=1)
        page.on('pageerror',lambda exc:issues.append(str(exc)))
        if root is None:
            page.goto('http://127.0.0.1:8765/#token=browser-validation-only',wait_until='networkidle')
        else:
            # Render the real UI on about:blank, with requests dispatched through
            # FastAPI TestClient. No browser URL-policy changes or network bypass.
            from fastapi.testclient import TestClient
            from shroud.server import create_app, STATIC
            app=create_app(root, token='browser-validation-only')
            client=TestClient(app)
            def dispatch(path, options):
                response=client.request(options.get('method','GET'),path,
                    headers=options.get('headers',{}),content=options.get('body'))
                return {'status':response.status_code,'headers':dict(response.headers),
                        'body':base64.b64encode(response.content).decode('ascii')}
            page.expose_function('_shroud_test_dispatch',dispatch)
            html=(STATIC/'index.html').read_text()
            html=html.replace('<link rel="stylesheet" href="/static/style.css">','')
            html=html.replace('<script src="/static/app.js" defer></script>','')
            page.set_content(html)
            page.add_style_tag(content=(STATIC/'style.css').read_text())
            page.add_script_tag(content="""
                Object.defineProperty(window,'sessionStorage',{value:{getItem:()=>
                    'browser-validation-only',setItem:()=>{}}});
                window.fetch=async(path,options={})=>{
                    const value=await window._shroud_test_dispatch(String(path),options);
                    const bytes=Uint8Array.from(atob(value.body),c=>c.charCodeAt(0));
                    return new Response(bytes,{status:value.status,headers:value.headers});
                };
            """)
            page.add_script_tag(content=(STATIC/'app.js').read_text())
        page.wait_for_selector('.art',timeout=10000)
        assert page.locator('.art').count()==6;checks.append('live catalog renders six fixture images')
        assert page.locator('#inspect-name').inner_text().endswith('.png');checks.append('selection populates inspector')
        page.screenshot(path=str(output/'library-desktop.png'),full_page=True)
        page.get_by_role('button',name='MED',exact=True).click();assert page.locator('.art').count()==0
        page.get_by_role('button',name='All sizes',exact=True).click();assert page.locator('.art').count()==6;checks.append('live size filtering')
        page.locator('#search').fill('2025');assert page.locator('.art').count()==2;page.locator('#search').fill('');checks.append('canonical date search')
        page.locator('#open-lab').click();page.wait_for_selector('#lab-view:not([hidden])');page.wait_for_timeout(500)
        assert page.locator('#transport-body tr').count()==8;checks.append('real trial measurements populate lab')
        page.locator('#split').fill('23');assert '23%' in page.locator('#candidate-clip').get_attribute('style');checks.append('before-after split control')
        page.screenshot(path=str(output/'lab-desktop.png'),full_page=True)
        page.get_by_role('button',name='Δ ×12',exact=True).click();page.wait_for_timeout(200);assert page.locator('#divider').is_hidden();checks.append('difference view')
        page.locator('[data-view=evidence]').click();page.wait_for_selector('.method-row');assert page.locator('.method-row').count()==12;checks.append('12 primary-source method records')
        page.locator('#audit').click();page.wait_for_selector('#report-dialog[open]');assert 'COMPLETE' in page.locator('#report-content').inner_text();page.locator('#report-dialog .dialog-close').click();checks.append('live workspace audit')
        page.locator('#scan').click();page.locator('#run-plan').click();page.wait_for_function("document.querySelector('#plan-result').textContent.includes('READ_ONLY')")
        assert page.locator('#apply').is_disabled();page.locator('#ack-remove').check();assert page.locator('#apply').is_enabled();checks.append('read-only migration preview and explicit source-removal gate')
        page.locator('#organize-dialog .dialog-close').click()
        page.locator('[data-view=library]').click()
        for width,height in [(1024,900),(390,844)]:
            page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(200)
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'),f'horizontal overflow at {width}'
            page.screenshot(path=str(output/f'library-{width}.png'),full_page=True)
            checks.append(f'no horizontal overflow at {width}px')
        assert not issues,issues
        checks.append('no browser JavaScript errors')
        browser.close()
        if root is not None:
            client.close()
            app.state.jobs.pool.shutdown(wait=True)
    report={'harness':'In-process FastAPI transport / Chromium about:blank rendering' if root else 'Live localhost HTTP','passed':len(checks),'checks':checks,'errors':issues,'fixture':'Synthetic geometric images; random-noise comparison is not protection evidence.'}
    (output/'browser-qa.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--in-process-root',type=Path)
    args=parser.parse_args()
    run(Path(__file__).resolve().parents[1]/'evidence',args.in_process_root)
