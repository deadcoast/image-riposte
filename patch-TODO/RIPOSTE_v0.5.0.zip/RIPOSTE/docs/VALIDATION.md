# RIPOSTE 0.5.0 / internal revision and package verification

This build reconstructs the requested terminal revision from the actual delivered 0.4.0 archive. The interrupted edit did not leave recoverable post-0.4 source. The reconstruction, original baseline and current files are distinguished in `evidence/provenance.json`.

## Executed before packaging

| Check | Result |
|---|---|
| Final source suite | 716 passed; 4 host warnings |
| Separately installed final local wheel | 716 passed; 4 host warnings |
| Inherited tests | All 667 cases retained; all 23 original test/fixture files byte-identical |
| New revision tests | 49 cases |
| Current package files | 47 |
| Source / wheel / separately installed package | 47 files byte-identical; see package-equality.json |
| Original package continuity | 34 files unchanged, 10 modified, 3 added; none removed |
| Image engines, organizer, sanitation, publication, storage and browser | Unchanged from the actual 0.4.0 archive |
| Native POSIX terminal | Normal exit, Ctrl+C, SIGTERM and live resizing exercised |
| Current native-terminal recording | Exit 0; 77 output events; 2.43 seconds |
| Recorded terminal background audit | No explicit background fill or reverse-video SGR commands |
| Transparent screenshot | RGBA; 691,349 completely transparent pixels |
| Shell launcher | `bash -n START.sh` passed |

The external `RIPOSTE_v0.5.0_release_report.json` is written only after ZIP creation, independent extraction, manifest checks and the full extracted test run. It contains the final archive hash and actual extracted result; these cannot be embedded in the archive without a circular dependency.

## Revision coverage

The new cases check the exact twelve goks tokens; default theme; foreground-only cells and Rich styles across every palette; resistance to accidental explicit fill arguments; Enter selection and separate inspection; shared contextual help; essential/advanced fields with value preservation; human reports; complete details and coloured JSON; narrow-layout/scroll bounds; and source-replacement confirmation. Semantic reports cover migration, audits, publishing plans, batches, runtime, image information and export receipts. Unknown expert results retain complete data through the field-tree and explicit JSON views.

The final native renderer was visually inspected at 79x24 and larger widths. Transparent/background checks complement the inspection; they are not a claim of universal readability on every custom terminal theme. RIPOSTE inherits the host background and does not change opacity or wallpaper.

## Execution environment and limits

The actual Typer parser, Rich cell/segment renderer, controller, POSIX alternate-screen input, worker lifecycle, real image reconstruction, publication state, output review, exact-byte package assembly and CPU tensor/codec code ran. Numerical model tests use explicitly synthetic components. This revision does not add a pretrained-model result or new AI-resistance claim.

The four warnings are Python 3.13 `forkpty()` deprecation warnings in the multithreaded test host. Test suites were run in the foreground: backgrounding pytest with a shell `&` causes child processes to inherit an ignored SIGINT in this environment and invalidates the interrupt scenario. Earlier background-shell interrupt failures were diagnosed as that invocation problem; product code and inherited tests were not changed to suppress the assertion.

The installed-wheel suite imports RIPOSTE from the separate target installation. It uses already installed third-party dependencies; it is not a clean-network or fully isolated dependency installation. Native Windows/macOS launchers, GPU execution and assistive-technology compatibility remain unverified. Existing Windows-key adapter checks use a mocked console.

## Source and evidence

The package includes developer checks, wheel, launchers and current source. Prior source/evidence remains under explicitly historical folders. The current GIF and PNGs are generated from the actual ASCII renderer using synthetic illustrations; dark/light screenshot canvases simulate host backgrounds. `terminal-report-transparent.png` has a transparent background. `terminal-session.cast` is a separate real POSIX-terminal recording. No screenshot or GIF is played as a substitute for runtime animation.

No user artwork, pretrained model weights, raw metadata backup or font file is bundled. Full-resolution image approval remains separate from the ASCII thumbnail. Passing numerical or interface checks does not establish copying/editing/video resistance. These are internal development checks, not a handoff asking the user to interrupt development and evaluate a prototype.
