# Current terminal design / 0.5

The current revision is specified in [REVISION-v05.md](REVISION-v05.md). Foreground-only goks, semantic reports, consistent Enter-first controls and contextual help supersede the older 0.4 background/focus/output descriptions. The original specification is preserved in `history/v0.4.0/docs/TERMINAL-DESIGN.spec.md`.

## Non-negotiable current contracts

1. Every cell uses the terminal-default background. No palette, focus state, ASCII artwork preview or animation may paint it.
2. The result itself must be designed: outcome, meaningful counts, task-specific sections, next action. Complete data is accessible without pretending a summary is complete.
3. One key-hint vocabulary supplies footers and contextual help. The focused field's effect is explained; Enter is the primary action.
4. Motion is preserved as authored ASCII geometry. It never impersonates processing progress and never delays input.
5. The main purpose remains clean artwork -> protected candidate files -> explicit review -> publishing pack. The workshop stays optional.
6. Machine JSON is a separate output contract. The interactive raw view is explicitly selected and syntax coloured.
