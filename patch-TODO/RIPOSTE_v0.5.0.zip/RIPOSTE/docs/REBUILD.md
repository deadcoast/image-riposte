# Build and package

This archive contains source, the matching pure-Python wheel, launchers, tests, documentation and a SHA-256 inventory. Optional ML dependencies and model weights are not bundled.

The release was reconstructed from the intact 0.4.0 archive because the failed revision's source files were unavailable. See REVISION-v05.md for the exact scope.

Run from the extracted RIPOSTE directory:

```powershell
.\START.ps1 -ArtworkFolder "D:\Artwork\SocialSamples"
```

The default palette is goks. Other terminal-owned-background variants are available with `-Theme light`, `-Theme mono` or `-Theme dark`. `-Lab` installs optional model-processing dependencies; it does not download weights.

For a direct command after setup:

```powershell
.\riposte.cmd --human organize "D:\Artwork\SocialSamples"
.\riposte.cmd --json list "D:\Artwork\SocialSamples"
```

Selecting a workspace and previewing organization are read-only. Source replacement still requires explicit authorization. Existing workspace/catalog formats have not changed.

A clean installation can use the included wheel with `python -m pip install dist/riposte_studio-0.5.0-py3-none-any.whl`. Its dependencies must be available; this archive is not a fully offline Python distribution.
